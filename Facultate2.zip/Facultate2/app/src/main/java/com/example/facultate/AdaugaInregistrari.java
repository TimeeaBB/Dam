package com.example.facultate;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class AdaugaInregistrari extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adauga_inregistari);

        //asa cauti controalele
        EditText etNumeStudent=findViewById(R.id.etNumeStudent);
        //spinner
        Spinner spinnerSpecializare=findViewById(R.id.spinnerSpecializare);
        EditText etAnStudiu = findViewById(R.id.etAnStudiu);
        EditText etMedie=findViewById(R.id.etMedie);
        CheckBox checkFinantare=findViewById(R.id.checkBoxFinantare);
        Button btnSalveaza=findViewById(R.id.buttonSalveaza);

        //facem un array de stringuri pt spinner

        String tipuriSpecializari[]={"CSIE","FABIZ","CIG"};

        //facem un array adapter
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,tipuriSpecializari);

        //acum incarcam spinnerul
        spinnerSpecializare.setAdapter(adapter);

        btnSalveaza.setOnClickListener(v-> {
            //pt nume
            String nume = etNumeStudent.getText().toString();
            if (nume.isEmpty()) {
                etNumeStudent.setError("Introdu numele studentului");
                return;
            }

            // pt anStudiu
            String anText = etAnStudiu.getText().toString();
            if (anText.isEmpty()) {
                etAnStudiu.setError("Dati anul de studiu!");
                return;
            }

            int an;
            try {
                an = Integer.parseInt(anText);
            } catch (NumberFormatException e) {
                etAnStudiu.setError("Anul trebuie sa fie un numar ");
                return;
            }

            if (an <= 0 || an > 4) {
                etAnStudiu.setError("Anul trebuie sa fie intre 1 si 4!");
                return;
            }


            //pt float medie
            String medieText=etMedie.getText().toString();
            if(medieText.isEmpty())
            {
                etMedie.setError("Dati media");
                return;
            }
            float medie;
            try{

                medie=Float.parseFloat(medieText);
            }catch(NumberFormatException e){
                etMedie.setError("Media trebuie sa fie un nr intreg");
                return;
            }
            if(medie<1.0f || medie>10.0f)
            {
                etMedie.setError("media trebuie sa fie intre 1 si 10");
                return;

            }


            String specializare=spinnerSpecializare.getSelectedItem().toString();
            boolean finantare=checkFinantare.isChecked();

            //apoi faci un obiect nou de tip studnt

            Student s = new Student(nume, specializare, an, medie, finantare);

            //pt cerinta 7
            //creezi un intent gol
            Intent intent=new Intent();

            intent.putExtra("studentNou",s); //pui studentul in intent
            setResult(RESULT_OK,intent);  //setezi rezultat
            finish(); //inchidere activitate
            //ok gata




        });
    }
}