package com.example.facultate;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id=item.getItemId();
        if(id==R.id.optiuneAdauga)
        {
            //deschidem activitatea de inregistrare
            Intent intent=new Intent(MainActivity.this,AdaugaInregistrari.class);
            startActivity(intent);
            return true;
        } else if (id==R.id.optiuneIesire) {
            //inchidem activitatea (si aplicatia daca asta e singura)
            finish();
            return true;
        }

        List<Student> listaStudenti;
        ArrayAdapter<Student> adapter;
        ListView listViewStudenti;




        return super.onOptionsItemSelected(item);
    }
}