package com.example.facultate;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Student implements Serializable
{
    //BOOLEAN PT CHECKBOX
    //cele minim 5 atribute
    private String numeStudent;
    private String specializare; // csie,mk,fabiz
    private int anStudiu;
    private float medie;
    private boolean finantare; //buget/taxa


    //constructorul implicit

    public Student()
    {

    }

    //constr cu param


    public Student(String numeStudent, String specializare, int anStudiu, float medie, boolean finantare) {
        this.numeStudent = numeStudent;
        this.specializare = specializare;
        this.anStudiu = anStudiu;
        this.medie = medie;
        this.finantare = finantare;
    }


    //getteri si setteri


    public String getNumeStudent() {
        return numeStudent;
    }

    public void setNumeStudent(String numeStudent) {
        this.numeStudent = numeStudent;
    }

    public String getSpecializare() {
        return specializare;
    }

    public void setSpecializare(String specializare) {
        this.specializare = specializare;
    }

    public int getAnStudiu() {
        return anStudiu;
    }

    public void setAnStudiu(int anStudiu) {
        this.anStudiu = anStudiu;
    }

    public float getMedie() {
        return medie;
    }

    public void setMedie(float medie) {
        this.medie = medie;
    }

    public boolean isFinantare() {
        return finantare;
    }

    public void setFinantare(boolean finantare) {
        this.finantare = finantare;
    }


    //toString method



    @Override
    public String toString() {
        return numeStudent + " - " + specializare + " _ " + anStudiu + " - " + medie + " - " + finantare + "  -  " ;
    }


}

//pana aici ai 2