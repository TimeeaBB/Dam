package com.example.extext1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        // MAI INTAI GASESTI BUTOANELE
        EditText etNume=findViewById(R.id.etNume);
        Spinner spinnerTipAbonament=findViewById(R.id.spinnerTipAbonament);
        EditText etDurataLuni=findViewById(R.id.etDurataLuni);
        EditText etPret=findViewById(R.id.etPret);
        CheckBox checkBoxActiv=findViewById(R.id.checkBoxActiv);
        Button butonSalveaza=findViewById(R.id.butonSalveaza);

        //creezi un string de  array uti cu valori (lunar,anual,student)
        String[]tipuri={"Anual","Lunar","Student"};

        //acum creezi un arrayadapter
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,tipuri);

        //legi adapatorul de spinner
        spinnerTipAbonament.setAdapter(adapter);

        butonSalveaza.setOnClickListener(v -> {
            // aici o sa validam

            String nume=etNume.getText().toString();
            if(nume.isEmpty())
            {
                etNume.setError("Introdu numele ");
                return;
            }

            String durataText=etDurataLuni.getText().toString();
            if(durataText.isEmpty())
            {
                etDurataLuni.setError("Introdu durata");  //asa verificam DACA E GOL
                return;
            }
            int durata;

            try {
                durata = Integer.parseInt(durataText);
            } catch (NumberFormatException e) {
                etDurataLuni.setError("Durata trebuie sa fie un numar intreg!");
                return;
            }

            if(durata<=0)
            {
                etDurataLuni.setError("Introdu durata luni");
                return;
            }

            //acum pentru pret


            String pretText=etPret.getText().toString();
            if(pretText.isEmpty())
            {
                etPret.setError("Introdu pretul");
                return;
            }
            float pret;
            try {
                pret = Float.parseFloat(pretText);
            } catch (NumberFormatException e) {
                etPret.setError("Pretul trebuie sa fie un numar!");
                return;
            }

            if (pret <= 0) {
                etPret.setError("Pretul trebuie sa fie > 0!");
                return;
            }
            String tipAbonament = spinnerTipAbonament.getSelectedItem().toString();
            boolean activ = checkBoxActiv.isChecked();

            ClubFitness cf = new ClubFitness(nume, tipAbonament, durata, pret,activ);

            Intent intent = new Intent();
            intent.putExtra("biletNou", cf);
            setResult(RESULT_OK, intent);
            finish();









        });

    }


}