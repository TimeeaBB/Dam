package com.example.extext1;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class ClubFitness implements Serializable {

    private String numeClient;
    private String tipAbonament; //lunar, anual, student
    private int durataLuni;
    private float pret;
    private boolean activ; //pentru checkbox

    //constructorul IMPLICIT

    public ClubFitness()
    {
        //ramane gol pt obiecte
    }

    //constructorul cu param


    public ClubFitness(String numeClient, String tipAbonament, int durataLuni, float pret, boolean activ) {
        this.numeClient = numeClient;
        this.tipAbonament = tipAbonament;
        this.durataLuni = durataLuni;
        this.pret = pret;
        this.activ = activ;
    }

    //getteri si setteri


    public String getNumeClient() {
        return numeClient;
    }

    public void setNumeClient(String numeClient) {
        this.numeClient = numeClient;
    }

    public String getTipAbonament() {
        return tipAbonament;
    }

    public void setTipAbonament(String tipAbonament) {
        this.tipAbonament = tipAbonament;
    }

    public int getDurataLuni() {
        return durataLuni;
    }

    public void setDurataLuni(int durataLuni) {
        this.durataLuni = durataLuni;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public boolean isActiv() {
        return activ;
    }

    public void setActiv(boolean activ) {
        this.activ = activ;
    }

    //metoda toString()

    @Override
    public String toString() {
        return numeClient + "  " + tipAbonament + "  " + durataLuni + " " + pret + " " + activ + "  ";

    }
}
